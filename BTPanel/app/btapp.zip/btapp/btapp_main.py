import sys
import os
os.chdir('/www/server/panel')
sys.path.insert(0,'class/')
import public

class btapp_main:
    def __init__(self):
        pass